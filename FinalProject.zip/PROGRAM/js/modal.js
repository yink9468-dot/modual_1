// js/modal.js - Complete modal functionality for Bean Boutique

document.addEventListener('DOMContentLoaded', () => {

  // ===== First Visitor Alert =====
(function showFirstVisitorAlert() {
  const alertKey = 'beanboutique_first_visit_alert';

  try {
    if (isFirstVisitor() && !localStorage.getItem(alertKey)) {
      alert('🎉 Welcome to Bean Boutique!\nFirst-time visitors get 10% OFF.\nClick "Order Now & Get 10% OFF!"');
      localStorage.setItem(alertKey, '1');
    }
  } catch (e) {
    console.warn(e);
  }
})();

  // ===== Welcome Modal =====
  const modal = document.getElementById('welcomeModal');
  const closeBtn = document.getElementById('closeModal');
  const modalForm = document.getElementById('modalForm');
  const seenKey = 'beanboutique_seen_modal_v1';

  // ===== Discount Modal =====
  const discountModal = document.getElementById('discountModal');
  const closeDiscountBtn = document.getElementById('closeDiscountModal');
  const closeDiscountBtn2 = document.getElementById('closeDiscountModal2');
  const copyCodeBtn = document.getElementById('copyCodeBtn');
  const goToShopBtn = document.getElementById('goToShopBtn');
  
  // ===== Global variables =====
  const cartCountElement = document.querySelector('.cart-count');

  // ===== Initialize everything =====
  initializeEverything();

  // ===== Check if user is first visitor =====
  function isFirstVisitor() {
    try {
      return localStorage.getItem(seenKey) !== '1';
    } catch (e) {
      console.warn('LocalStorage not available:', e);
      return true;
    }
  }

  // ===== Welcome Modal Functions =====
  function openModal() {
    if (!modal) return;
    modal.setAttribute('aria-hidden', 'false');
    const focusable = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
    const first = focusable[0];
    first && first.focus();
  }

  function closeModal() {
    if (!modal) return;
    modal.setAttribute('aria-hidden', 'true');
    try { 
      localStorage.setItem(seenKey, '1'); 
    } catch (e) {
      console.warn('LocalStorage not available:', e);
    }
  }

  // ===== Discount Modal Functions =====
  function openDiscountModal() {
    if (!discountModal) return;
    
    // Check if user has signed up for email
    if (!hasSignedUp()) {
      // If not signed up, open welcome modal instead
      showToast('Please sign up with your email to get your discount!', 'info');
      openModal(); // Open welcome modal for email sign up
      return; // Don't open discount modal
    }
    
    // Get discount code
    let discountCode = getDiscountCode();
    
    // Display the discount code
    const discountCodeElement = discountModal.querySelector('.discount-code');
    if (discountCodeElement) {
      discountCodeElement.textContent = discountCode;
    }
    
    discountModal.setAttribute('aria-hidden', 'false');
    
    // Focus on the close button
    if (closeDiscountBtn) {
      closeDiscountBtn.focus();
    }
  }

  function closeDiscountModal() {
    if (!discountModal) return;
    discountModal.setAttribute('aria-hidden', 'true');
  }

  // ===== Get Discount Code Function =====
  function getDiscountCode() {
    try {
      let discountCode = localStorage.getItem('beanboutique_discount_code');
      if (!discountCode) {
        discountCode = generateDiscountCode();
        localStorage.setItem('beanboutique_discount_code', discountCode);
      }
      return discountCode;
    } catch (e) {
      console.warn('LocalStorage not available:', e);
      return 'BEAN10OFF';
    }
  }

  // ===== Generate Discount Code =====
  function generateDiscountCode() {
    const prefix = 'BEAN';
    const numbers = Math.floor(100 + Math.random() * 900);
    const letters = String.fromCharCode(65 + Math.floor(Math.random() * 26)) + 
                   String.fromCharCode(65 + Math.floor(Math.random() * 26));
    return `${prefix}${numbers}${letters}`;
  }

  // ===== Email Sign Up Check Function =====
  function hasSignedUp() {
    try {
      const userEmail = localStorage.getItem('beanboutique_user_email');
      return userEmail !== null && userEmail.trim() !== '';
    } catch (e) {
      console.warn('LocalStorage not available:', e);
      return false;
    }
  }

  // ===== Cart Functions =====
  function updateCartCount() {
    if (cartCountElement) {
      try {
        const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
        const cartCount = cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0);
        
        cartCountElement.textContent = cartCount;
        
        // Add visual feedback if cart has items
        if (cartCount > 0) {
          cartCountElement.style.background = '#e74c3c';
          cartCountElement.style.color = 'white';
        } else {
          cartCountElement.style.background = 'var(--accent)';
          cartCountElement.style.color = 'white';
        }
      } catch (e) {
        console.warn('Could not update cart count:', e);
      }
    }
    
    // Update all cart count elements on page
    const allCartCountElements = document.querySelectorAll('.cart-count');
    allCartCountElements.forEach(element => {
      if (element !== cartCountElement) {
        try {
          const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
          const cartCount = cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0);
          element.textContent = cartCount;
        } catch (e) {
          console.warn('Could not update all cart counts:', e);
        }
      }
    });
  }

  // Toast notification function
  function showToast(message, type = 'info') {
    // Remove existing toast if any
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
      existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toast.style.cssText = `
      position: fixed;
      top: 80px;
      right: 20px;
      background: ${type === 'success' ? '#27ae60' : 
                   type === 'error' ? '#e74c3c' : 
                   type === 'info' ? '#3498db' : '#3498db'};
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 1000;
      animation: slideIn 0.3s ease, fadeOut 0.3s ease 2.7s;
      animation-fill-mode: forwards;
    `;
    
    document.body.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
      if (toast.parentNode) {
        toast.remove();
      }
    }, 3000);
  }

  // ===== Event Listeners =====

  // ===== Order Now Button =====
const orderNowBtn = document.querySelector('.order-now-btn');

if (orderNowBtn) {
  orderNowBtn.addEventListener('click', () => {

    // Not SignedUp Email
    if (!hasSignedUp()) {
      openModal(); // Welcome modal
      return;
    }

    // Already signedup Email
    openDiscountModal(); // Discount modal (repeatable)
  });
}


  // Welcome Modal
  closeBtn && closeBtn.addEventListener('click', () => closeModal());
  
  modal && modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Welcome Modal Form Submit
  modalForm && modalForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const emailInput = modalForm.querySelector('input[type="email"]');
    const email = emailInput?.value || '';
    
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      showToast('Please enter a valid email address.', 'error');
      emailInput && emailInput.focus();
      return;
    }

    // Save email and generate discount code
    const discountCode = getDiscountCode();
    try { 
      localStorage.setItem(seenKey, '1');
      localStorage.setItem('beanboutique_discount_code', discountCode);
      localStorage.setItem('beanboutique_user_email', email);
    } catch (e) {
      console.warn('LocalStorage not available:', e);
    }
    
    closeModal();
    
    // Show success message with discount code
    setTimeout(() => {
      showToast(`🎉 Thank you! Your discount code: ${discountCode}`, 'success');
      // Automatically open discount modal after sign up
      setTimeout(() => {
        openDiscountModal();
      }, 1000);
    }, 300);
  });

  // Discount Modal Close Buttons
  if (closeDiscountBtn) {
    closeDiscountBtn.addEventListener('click', closeDiscountModal);
  }

  if (closeDiscountBtn2) {
    closeDiscountBtn2.addEventListener('click', closeDiscountModal);
  }

  if (discountModal) {
    discountModal.addEventListener('click', (e) => {
      if (e.target === discountModal) closeDiscountModal();
    });
  }

  // Copy Discount Code
  if (copyCodeBtn) {
    copyCodeBtn.addEventListener('click', function() {
      const discountCodeElement = discountModal.querySelector('.discount-code');
      const discountCode = discountCodeElement ? discountCodeElement.textContent : getDiscountCode();
      
      navigator.clipboard.writeText(discountCode).then(() => {
        const originalText = this.textContent;
        this.textContent = 'Copied! ✓';
        this.style.background = '#27ae60';
        
        showToast('Discount code copied to clipboard!', 'success');
        
        setTimeout(() => {
          this.textContent = originalText;
          this.style.background = '';
        }, 2000);
      }).catch(err => {
        console.warn('Failed to copy:', err);
        showToast('Failed to copy code. Please select and copy manually.', 'error');
      });
    });
  }

  // Go to Shop Button
  if (goToShopBtn) {
    goToShopBtn.addEventListener('click', function() {
      closeDiscountModal();
      window.location.href = 'coffee.html';
    });
  }

  // ===== Coffee Page Add to Cart Buttons =====
  const coffeeAddToCartButtons = document.querySelectorAll('.coffee-btn');
  
  coffeeAddToCartButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Get product details
      const coffeeCard = this.closest('.coffee-card');
      if (!coffeeCard) return;
      
      const coffeeName = coffeeCard.querySelector('h3').textContent;
      const coffeePrice = coffeeCard.querySelector('.price').textContent;
      const coffeeImage = coffeeCard.querySelector('img').src;
      
      // Extract just the filename from the full path
      const imageName = coffeeImage.split('/').pop();
      const imagePath = 'images/' + imageName;
      
      // Toggle cart item
      toggleCartItem(coffeeName, coffeePrice, imagePath);
      
      // Update button text
      updateButtonState(this, coffeeName);
      
      // Add cart animation
      const cartIcon = document.querySelector('.cart-link svg');
      if (cartIcon) {
        cartIcon.style.transform = 'scale(1.3)';
        setTimeout(() => {
          cartIcon.style.transform = 'scale(1)';
        }, 300);
      }
    });
  });

  // ===== Equipment Page Add to Cart Buttons =====
  const equipmentButtons = document.querySelectorAll('.equipment-btn');
  
  equipmentButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Get product details
      const equipmentCard = this.closest('.equipment-card');
      if (!equipmentCard) return;
      
      const equipmentName = equipmentCard.querySelector('h3').textContent;
      const equipmentPrice = equipmentCard.querySelector('.price').textContent;
      const equipmentImage = equipmentCard.querySelector('img').src;
      
      // Extract just the filename from the full path
      const imageName = equipmentImage.split('/').pop();
      const imagePath = 'images/' + imageName;
      
      // Toggle cart item
      toggleCartItem(equipmentName, equipmentPrice, imagePath);
      
      // Update button text
      updateButtonState(this, equipmentName);
      
      // Add cart animation
      const cartIcon = document.querySelector('.cart-link svg');
      if (cartIcon) {
        cartIcon.style.transform = 'scale(1.3)';
        setTimeout(() => {
          cartIcon.style.transform = 'scale(1)';
        }, 300);
      }
    });
  });

  // ===== Toggle Cart Item Function =====
  function toggleCartItem(productName, price, imageSrc) {
    try {
      let cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      
      // Check if item already exists
      const existingItemIndex = cartItems.findIndex(item => item.name === productName);
      
      if (existingItemIndex !== -1) {
        // Remove from cart
        cartItems.splice(existingItemIndex, 1);
        showToast(`${productName} removed from cart!`, 'info');
      } else {
        // Add to cart
        const image = imageSrc || getImageForProduct(productName);
        
        cartItems.push({
          name: productName,
          price: price,
          image: image,
          quantity: 1,
          type: productName.includes('Espresso') || productName.includes('Grinder') || 
                productName.includes('French Press') || productName.includes('Pour Over') ||
                productName.includes('Scale') || productName.includes('Kettle') ? 'equipment' : 'coffee'
        });
        
        showToast(`${productName} added to cart!`, 'success');
      }
      
      // Save to localStorage
      localStorage.setItem('beanboutique_cart_items', JSON.stringify(cartItems));
      
      // Update cart count
      updateCartCount();
      
      // Update all button states on page
      updateAllButtonStates();
      
    } catch (e) {
      console.warn('Could not toggle cart item:', e);
    }
  }

  // ===== Update Button State =====
  function updateButtonState(button, productName) {
    try {
      const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      const inCart = cartItems.some(item => item.name === productName);
      
      if (inCart) {
        button.textContent = 'Remove from Cart';
        button.style.background = '#e74c3c';
        button.classList.add('in-cart');
      } else {
        button.textContent = 'Add to Cart';
        button.style.background = 'var(--primary)';
        button.classList.remove('in-cart');
      }
    } catch (e) {
      console.warn('Could not update button state:', e);
    }
  }

  // ===== Update All Button States =====
  function updateAllButtonStates() {
    try {
      const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      
      // Update coffee buttons
      const coffeeButtons = document.querySelectorAll('.coffee-btn');
      coffeeButtons.forEach(button => {
        const coffeeCard = button.closest('.coffee-card');
        if (!coffeeCard) return;
        
        const coffeeName = coffeeCard.querySelector('h3').textContent;
        const inCart = cartItems.some(item => item.name === coffeeName);
        
        if (inCart) {
          button.textContent = 'Remove from Cart';
          button.style.background = '#e74c3c';
          button.classList.add('in-cart');
        } else {
          button.textContent = 'Add to Cart';
          button.style.background = 'var(--primary)';
          button.classList.remove('in-cart');
        }
      });
      
      // Update equipment buttons
      const equipmentButtons = document.querySelectorAll('.equipment-btn');
      equipmentButtons.forEach(button => {
        const equipmentCard = button.closest('.equipment-card');
        if (!equipmentCard) return;
        
        const equipmentName = equipmentCard.querySelector('h3').textContent;
        const inCart = cartItems.some(item => item.name === equipmentName);
        
        if (inCart) {
          button.textContent = 'Remove from Cart';
          button.style.background = '#e74c3c';
          button.classList.add('in-cart');
        } else {
          button.textContent = 'Add to Cart';
          button.style.background = 'var(--primary)';
          button.classList.remove('in-cart');
        }
      });
      
    } catch (e) {
      console.warn('Could not update all button states:', e);
    }
  }

  // ===== Get Image for Product =====
  function getImageForProduct(productName) {
    // Coffee images
    const coffeeImageMap = {
      'Signature Blend': 'images/coffee1.jpg',
      'Medium Roast': 'images/Aroma.jpg',
      'Colombian Supremo': 'images/colombia.jpg',
      'Ethiopian Yirgacheffe': 'images/Latte.jpg',
      'Dark Roast': 'images/dark_roast.jpg',
      'Espresso Beans': 'images/espresso1.png',
      'Guatemalan Antigua': 'images/coffee1.jpg',
      'Brazilian Santos': 'images/Brazilian1.jpg',
      'Sumatra Mandheling': 'images/dark_chocolate.png'
    };
    
    if (coffeeImageMap[productName]) {
      return coffeeImageMap[productName];
    }
    
    // Equipment images
    const equipmentImageMap = {
      'Professional Espresso Machine': 'images/espresso.jpg',
      'Home Barista Espresso Machine': 'images/expressomachine.png',
      'Hario V60 Ceramic Dripper Set': 'images/dripper.jpg',
      'Chemex Classic Series': 'images/chemex-pouring.jpg',
      'Stainless Steel French Press': 'images/FrenchPress1.jpg',
      'Classic Glass French Press': 'images/glassfresh.jpg',
      'Conical Burr Grinder': 'images/Grinder1.jpg',
      'Manual Hand Grinder': 'images/Grinder2.jpg',
      'Precision Coffee Scale': 'images/coffeescale.jpg',
      'Temperature Control Gooseneck Kettle': 'images/Gooseneckkettle.jpg'
    };
    
    return equipmentImageMap[productName] || 'images/coffee1.jpg';
  }

  // ===== Mobile Navigation Toggle =====
  const mobileNavToggle = document.getElementById('mobileNavToggle');
  const primaryNav = document.getElementById('primaryNav');
  
  if (mobileNavToggle && primaryNav) {
    mobileNavToggle.addEventListener('click', function() {
      const isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
      primaryNav.classList.toggle('open');
    });
  }

  // ===== Category Navigation for Equipment Page =====
  const categoryLinks = document.querySelectorAll('.category-card[href^="#"]');
  categoryLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 100,
          behavior: 'smooth'
        });
      }
    });
  });

  // ===== First Visitor Auto Modal =====
  function checkFirstVisitor() {
    // Check if on index.html
    if (window.location.pathname.includes('index.html') || 
        window.location.pathname === '/' || 
        window.location.pathname.endsWith('/')) {
      
      // Check if first visitor and hasn't signed up yet
      if (isFirstVisitor() && !hasSignedUp()) {
        // Show modal after 1 second delay
        setTimeout(() => {
          openModal();
        }, 1000);
      }
    }
  }

  // ===== Cart Page Functions =====
  function initializeCartPage() {
    // Check if we're on cart page
    if (window.location.pathname.includes('cart.html')) {
      // Load cart items on page load
      setTimeout(loadCartItems, 100);
      
      // Clear cart button
      const clearCartBtn = document.getElementById('clearCartBtn');
      if (clearCartBtn) {
        clearCartBtn.addEventListener('click', function() {
          clearCartPage();
        });
      }
      
      // Continue shopping button
      const continueShoppingBtn = document.getElementById('continueShopping');
      if (continueShoppingBtn) {
        continueShoppingBtn.addEventListener('click', function() {
          window.location.href = 'coffee.html';
        });
      }
      
      // Checkout button
      const checkoutBtn = document.getElementById('checkoutBtn');
      if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function() {
          proceedToCheckout();
        });
      }
      
      // Apply discount button
      const applyDiscountBtn = document.getElementById('applyDiscount');
      if (applyDiscountBtn) {
        applyDiscountBtn.addEventListener('click', applyDiscountCode);
      }
      
      // Enter key for discount code
      const discountCodeInput = document.getElementById('discountCode');
      if (discountCodeInput) {
        discountCodeInput.addEventListener('keypress', function(e) {
          if (e.key === 'Enter') {
            applyDiscountCode();
          }
        });
      }
      
      // Auto-fill discount code if user has one
      window.addEventListener('load', function() {
        const discountCode = getDiscountCode();
        const userEmail = localStorage.getItem('beanboutique_user_email');
        
        if (userEmail && discountCodeInput) {
          discountCodeInput.value = discountCode;
          // Auto-apply the discount
          setTimeout(applyDiscountCode, 500);
        }
      });
    }
  }

  // Load cart items function
  function loadCartItems() {
    try {
      const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      const cartContainer = document.getElementById('cartItems');
      const emptyMessage = document.getElementById('emptyCartMessage');
      const cartSummary = document.getElementById('cartSummary');
      
      if (!cartContainer || !emptyMessage || !cartSummary) return;
      
      if (cartItems.length === 0) {
        emptyMessage.style.display = 'block';
        cartSummary.style.display = 'none';
        return;
      }
      
      emptyMessage.style.display = 'none';
      cartSummary.style.display = 'block';
      
      let html = '';
      let subtotal = 0;
      
      cartItems.forEach((item, index) => {
        const price = parseFloat(item.price.replace(/[^0-9.-]+/g, ""));
        const itemTotal = price * (item.quantity || 1);
        subtotal += itemTotal;
        
        const imageSrc = item.image || getImageForProduct(item.name);
        
        html += `
          <div class="cart-item" data-index="${index}" data-price="${price}">
            <img src="${imageSrc}" alt="${item.name}" class="cart-item-image" onerror="this.src='images/coffee1.jpg'">
            <div class="cart-item-details">
              <h3>${item.name}</h3>
              <div class="cart-item-price">$${price.toFixed(2)}</div>
              <div class="quantity-controls">
                <button class="quantity-btn minus-btn" onclick="window.updateQuantity(${index}, -1)">-</button>
                <span class="quantity-display">${item.quantity || 1}</span>
                <button class="quantity-btn plus-btn" onclick="window.updateQuantity(${index}, 1)">+</button>
              </div>
            </div>
            <div class="item-total">$${itemTotal.toFixed(2)}</div>
            <button class="btn remove-item-btn" onclick="window.removeCartItemByIndex(${index})" style="background: #e74c3c; padding: 8px 15px;">Remove</button>
          </div>
        `;
      });
      
      cartContainer.innerHTML = html;
      updateCartSummary(subtotal);
      
    } catch (e) {
      console.warn('Could not load cart items:', e);
    }
  }

  // Update quantity function
  window.updateQuantity = function(index, change) {
    try {
      let cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      
      if (index >= 0 && index < cartItems.length) {
        if (!cartItems[index].quantity) {
          cartItems[index].quantity = 1;
        }
        
        cartItems[index].quantity += change;
        
        if (cartItems[index].quantity < 1) {
          cartItems[index].quantity = 1;
        }
        
        localStorage.setItem('beanboutique_cart_items', JSON.stringify(cartItems));
        
        updateCartCount();
        loadCartItems();
        showToast('Quantity updated!', 'info');
      }
    } catch (e) {
      console.warn('Could not update quantity:', e);
    }
  }

  // Remove cart item function
  window.removeCartItemByIndex = function(index) {
    try {
      let cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      
      if (index >= 0 && index < cartItems.length) {
        const itemName = cartItems[index].name;
        cartItems.splice(index, 1);
        
        localStorage.setItem('beanboutique_cart_items', JSON.stringify(cartItems));
        
        updateCartCount();
        loadCartItems();
        showToast(`${itemName} removed from cart!`, 'info');
      }
    } catch (e) {
      console.warn('Could not remove cart item:', e);
    }
  }

  // Update cart summary function
  function updateCartSummary(subtotal) {
    const discountCodeInput = document.getElementById('discountCode');
    const discountCode = discountCodeInput?.value || '';
    let discountPercentage = 0;
    
    // Check if discount code is valid (can use own code or BEAN10OFF)
    if (discountCode === getDiscountCode() || discountCode === 'BEAN10OFF' || 
        discountCode === 'WELCOME10' || discountCode === 'FIRST10') {
      discountPercentage = 10;
    }
    
    const discountAmount = subtotal * (discountPercentage / 100);
    const total = subtotal - discountAmount;
    
    const subtotalElement = document.getElementById('subtotal');
    const discountAmountElement = document.getElementById('discountAmount');
    const cartTotalElement = document.getElementById('cartTotal');
    
    if (subtotalElement) subtotalElement.textContent = `$${subtotal.toFixed(2)}`;
    if (discountAmountElement) discountAmountElement.textContent = `-$${discountAmount.toFixed(2)}`;
    if (cartTotalElement) cartTotalElement.textContent = `$${total.toFixed(2)}`;
  }

  // Apply discount code function
  function applyDiscountCode() {
    const discountCodeInput = document.getElementById('discountCode');
    const discountMessage = document.getElementById('discountMessage');
    
    if (!discountCodeInput || !discountMessage) return;
    
    const code = discountCodeInput.value.trim().toUpperCase();
    const userDiscountCode = getDiscountCode();
    
    if (code === '') {
      discountMessage.innerHTML = 'Please enter a discount code.';
      discountMessage.className = 'discount-message discount-error';
      return;
    }
    
    // Check if code matches user's code or universal codes
    if (code === userDiscountCode || code === 'BEAN10OFF' || 
        code === 'WELCOME10' || code === 'FIRST10') {
      discountMessage.innerHTML = '🎉 Discount applied! You saved 10% on your order.';
      discountMessage.className = 'discount-message discount-success';
      
      setTimeout(() => {
        calculateCartTotal();
      }, 100);
      
      showToast('Discount code applied successfully!', 'success');
    } else {
      discountMessage.innerHTML = 'Invalid discount code. Please check and try again.';
      discountMessage.className = 'discount-message discount-error';
      
      setTimeout(() => {
        calculateCartTotal();
      }, 100);
    }
  }

  // Calculate cart total function
  function calculateCartTotal() {
    try {
      const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      let subtotal = 0;
      
      cartItems.forEach(item => {
        const price = parseFloat(item.price.replace(/[^0-9.-]+/g, ""));
        subtotal += price * (item.quantity || 1);
      });
      
      updateCartSummary(subtotal);
    } catch (e) {
      console.warn('Could not calculate cart total:', e);
    }
  }

  // Proceed to checkout function
  function proceedToCheckout() {
    try {
      const cartItems = JSON.parse(localStorage.getItem('beanboutique_cart_items') || '[]');
      
      if (cartItems.length === 0) {
        alert('Your cart is empty. Please add items before checkout.');
        return;
      }
      
      let subtotal = 0;
      cartItems.forEach(item => {
        const price = parseFloat(item.price.replace(/[^0-9.-]+/g, ""));
        subtotal += price * (item.quantity || 1);
      });
      
      const discountCodeInput = document.getElementById('discountCode');
      const discountCode = discountCodeInput?.value || '';
      const userDiscountCode = getDiscountCode();
      let discountPercentage = 0;
      
      if (discountCode === userDiscountCode || discountCode === 'BEAN10OFF' || 
          discountCode === 'WELCOME10' || discountCode === 'FIRST10') {
        discountPercentage = 10;
      }
      
      const discountAmount = subtotal * (discountPercentage / 100);
      const total = subtotal - discountAmount;
      
      let orderDetails = 'Order Summary:\n\n';
      cartItems.forEach(item => {
        const price = parseFloat(item.price.replace(/[^0-9.-]+/g, ""));
        const itemTotal = price * (item.quantity || 1);
        orderDetails += `${item.name} x${item.quantity || 1}: $${itemTotal.toFixed(2)}\n`;
      });
      
      orderDetails += `\nSubtotal: $${subtotal.toFixed(2)}`;
      
      if (discountPercentage > 0) {
        orderDetails += `\nDiscount (${discountPercentage}%): -$${discountAmount.toFixed(2)}`;
        orderDetails += `\nDiscount Code: ${discountCode}`;
      }
      
      orderDetails += `\nTotal: $${total.toFixed(2)}`;
      
      const confirmed = confirm(`${orderDetails}\n\nProceed to payment?`);
      
      if (confirmed) {
        alert('Thank you for your order!\n\nThis is a demo store. In a real implementation, you would be redirected to a payment gateway.\n\nYour order has been placed successfully!');
        
        clearCartPage();
        
        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1000);
      }
    } catch (e) {
      console.warn('Could not proceed to checkout:', e);
    }
  }

  // Clear cart page function
  function clearCartPage() {
    if (confirm('Are you sure you want to clear your cart?')) {
      try {
        localStorage.setItem('beanboutique_cart_items', '[]');
        
        updateCartCount();
        loadCartItems();
        
        const discountCodeInput = document.getElementById('discountCode');
        const discountMessage = document.getElementById('discountMessage');
        
        if (discountCodeInput) discountCodeInput.value = '';
        if (discountMessage) {
          discountMessage.innerHTML = '';
          discountMessage.className = 'discount-message';
        }
        
        showToast('Cart cleared!', 'info');
      } catch (e) {
        console.warn('Could not clear cart:', e);
      }
    }
  }

  // ===== Accessibility & Keyboard Navigation =====
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (modal && modal.getAttribute('aria-hidden') === 'false') {
        closeModal();
      }
      if (discountModal && discountModal.getAttribute('aria-hidden') === 'false') {
        closeDiscountModal();
      }
    }
    
    if (modal && modal.getAttribute('aria-hidden') === 'false') {
      trapFocus(modal, e);
    }
    if (discountModal && discountModal.getAttribute('aria-hidden') === 'false') {
      trapFocus(discountModal, e);
    }
  });

  // Function to trap focus inside modal
  function trapFocus(modalElement, event) {
    const focusableElements = modalElement.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    if (focusableElements.length === 0) return;
    
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    if (event.key === 'Tab') {
      if (event.shiftKey) {
        if (document.activeElement === firstElement) {
          event.preventDefault();
          lastElement.focus();
        }
      } else {
        if (document.activeElement === lastElement) {
          event.preventDefault();
          firstElement.focus();
        }
      }
    }
  }

  // ===== Initialize Everything =====
  function initializeEverything() {
    // Check for first visitor on index.html
    checkFirstVisitor();
    
    // Update cart count and button states
    updateCartCount();
    updateAllButtonStates();
    
    // Initialize cart page if on cart page
    initializeCartPage();
  }
});
/* =====================================================
   main.js – Professional Mobile Navigation
   Bean Boutique
   ===================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ===============================
     MOBILE NAVIGATION
     =============================== */

  const mobileNavToggle = document.getElementById('mobileNavToggle');
  const primaryNav = document.getElementById('primaryNav');
  const navBackdrop = document.getElementById('navBackdrop');

  if (!mobileNavToggle || !primaryNav) return;

  // OPEN / CLOSE MENU
  function toggleMenu(forceClose = false) {
    const isOpen = forceClose
      ? false
      : !primaryNav.classList.contains('nav-open');

    primaryNav.classList.toggle('nav-open', isOpen);
    mobileNavToggle.setAttribute('aria-expanded', isOpen);

    if (navBackdrop) {
      navBackdrop.classList.toggle('show', isOpen);
    }

    // Prevent background scroll
    document.body.style.overflow = isOpen ? 'hidden' : '';
  }

  // Toggle button click
  mobileNavToggle.addEventListener('click', () => {
    toggleMenu();
  });

  // Close when clicking backdrop
  if (navBackdrop) {
    navBackdrop.addEventListener('click', () => {
      toggleMenu(true);
    });
  }

  // Close when clicking any nav link
  primaryNav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      toggleMenu(true);
    });
  });

  // Close on ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && primaryNav.classList.contains('nav-open')) {
      toggleMenu(true);
    }
  });

  // Close menu if screen resized to desktop
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      toggleMenu(true);
    }
  });

});

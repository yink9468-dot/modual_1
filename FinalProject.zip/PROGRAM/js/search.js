// js/search.js - Animated Product Search & Filter Plugin for Bean Boutique
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('coffeeSearch');
    const coffeeCards = document.querySelectorAll('.coffee-card');
    const resultsCount = document.getElementById('searchResultsCount');
    const coffeeGrid = document.querySelector('.coffee-grid');
    
    // Early exit if no search input
    if (!searchInput) return;
    
    // Initialize all cards as visible
    coffeeCards.forEach(card => {
        card.classList.add('visible');
    });
    
    // Function to perform search with animation
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        let visibleCount = 0;
        
        // If search is empty, show all cards
        if (searchTerm === '') {
            coffeeCards.forEach(card => {
                card.classList.remove('hidden');
                setTimeout(() => {
                    card.classList.add('visible');
                }, 50);
                visibleCount++;
            });
            
            if (resultsCount) {
                resultsCount.textContent = `Showing all ${visibleCount} premium coffees`;
                resultsCount.style.color = '#6b3e26';
            }
            return;
        }
        
        // Search through each card
        coffeeCards.forEach((card, index) => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const description = card.querySelector('.description').textContent.toLowerCase();
            const tastingNotes = card.querySelector('.tasting-notes')?.textContent.toLowerCase() || '';
            const brewingMethods = card.querySelector('.brewing-methods')?.textContent.toLowerCase() || '';
            
            // Check if any field contains the search term
            const matches = title.includes(searchTerm) || 
                          description.includes(searchTerm) || 
                          tastingNotes.includes(searchTerm) || 
                          brewingMethods.includes(searchTerm);
            
            // Add delay for staggered animation
            const delay = index * 50;
            
            if (matches) {
                setTimeout(() => {
                    card.classList.remove('hidden');
                    card.classList.add('visible');
                }, delay);
                visibleCount++;
            } else {
                setTimeout(() => {
                    card.classList.remove('visible');
                    card.classList.add('hidden');
                }, delay);
            }
        });
        
        // Update results count with animation
        if (resultsCount) {
            resultsCount.style.opacity = '0';
            resultsCount.style.transform = 'translateY(-5px)';
            
            setTimeout(() => {
                if (visibleCount === 0) {
                    resultsCount.textContent = `No products found for "${searchTerm}". Try a different search term.`;
                    resultsCount.style.color = '#d9534f';
                } else {
                    resultsCount.textContent = `Found ${visibleCount} product${visibleCount !== 1 ? 's' : ''} matching "${searchTerm}"`;
                    resultsCount.style.color = '#6b3e26';
                }
                
                resultsCount.style.opacity = '1';
                resultsCount.style.transform = 'translateY(0)';
                resultsCount.style.transition = 'all 0.3s ease';
            }, 300);
        }
    }
    
    // Event listener for real-time search with debounce
    let searchTimeout;
    searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(performSearch, 300);
        
        // Add pulsing animation to search icon during search
        const searchIcon = document.querySelector('.search-icon');
        if (searchIcon) {
            searchIcon.style.animation = 'pulse 0.5s ease';
            setTimeout(() => {
                searchIcon.style.animation = '';
            }, 500);
        }
    });
    
    // Clear search button
    const clearSearch = () => {
        searchInput.value = '';
        performSearch();
        searchInput.focus();
    };
    
    // Add clear button dynamically
    const searchContainer = document.querySelector('.search-container');
    if (searchContainer) {
        const clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'clear-search';
        clearBtn.innerHTML = '&times;';
        clearBtn.setAttribute('aria-label', 'Clear search');
        clearBtn.style.cssText = `
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            font-size: 1.5rem;
            color: #a99c8f;
            cursor: pointer;
            display: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        `;
        
        clearBtn.addEventListener('mouseenter', () => {
            clearBtn.style.backgroundColor = 'rgba(0,0,0,0.05)';
            clearBtn.style.color = '#6b3e26';
        });
        
        clearBtn.addEventListener('mouseleave', () => {
            clearBtn.style.backgroundColor = 'transparent';
            clearBtn.style.color = '#a99c8f';
        });
        
        clearBtn.addEventListener('click', clearSearch);
        searchContainer.appendChild(clearBtn);
        
        // Show/hide clear button based on input
        searchInput.addEventListener('input', () => {
            if (searchInput.value.length > 0) {
                clearBtn.style.display = 'flex';
            } else {
                clearBtn.style.display = 'none';
            }
        });
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Ctrl/Cmd + F to focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
            e.preventDefault();
            searchInput.focus();
            searchInput.select();
        }
        
        // Escape to clear search
        if (e.key === 'Escape' && document.activeElement === searchInput) {
            clearSearch();
        }
    });
    
    // Add CSS for pulse animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pulse {
            0% { transform: translateY(-50%) scale(1); }
            50% { transform: translateY(-50%) scale(1.1); }
            100% { transform: translateY(-50%) scale(1); }
        }
        
        .clear-search:hover {
            background-color: rgba(107, 62, 38, 0.1) !important;
            color: #6b3e26 !important;
        }
        
        .search-highlight {
            background-color: rgba(199, 155, 99, 0.3);
            padding: 2px 4px;
            border-radius: 3px;
        }
        
        /* Filter section styles */
        .filter-section {
            padding: 20px 0;
            background: #f9f5f0;
            margin-top: 20px;
        }
        
        .filter-container {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            min-width: 150px;
        }
        
        .filter-group label {
            font-size: 0.9rem;
            color: #6b3e26;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .filter-select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background: white;
            font-size: 0.9rem;
        }
        
        .active-filters {
            margin-top: 15px;
            padding: 10px;
            background: white;
            border-radius: 4px;
            border-left: 4px solid #c79b63;
        }
        
        #activeFilterText {
            color: #6b3e26;
            font-weight: 500;
        }
        
        /* Coffee card animation */
        .coffee-card {
            transition: all 0.3s ease;
        }
        
        .coffee-card.visible {
            opacity: 1;
            transform: translateY(0);
            display: block;
        }
        
        .coffee-card.hidden {
            opacity: 0;
            transform: translateY(20px);
            display: none;
        }
    `;
    document.head.appendChild(style);
    
    // Highlight matching text (advanced feature)
    function highlightMatches(text, searchTerm) {
        if (!searchTerm) return text;
        
        const regex = new RegExp(`(${searchTerm})`, 'gi');
        return text.replace(regex, '<span class="search-highlight">$1</span>');
    }
    
    // Initialize with all products shown
    if (resultsCount) {
        resultsCount.textContent = `Showing all ${coffeeCards.length} premium coffees`;
        resultsCount.style.color = '#6b3e26';
    }
    
    // Add search instructions tooltip on focus
    searchInput.addEventListener('focus', () => {
        if (!searchInput.hasAttribute('data-tooltip-shown')) {
            setTimeout(() => {
                if (resultsCount) {
                    const originalText = resultsCount.textContent;
                    resultsCount.textContent = 'Tip: Search by coffee name, tasting notes (e.g., "chocolate"), or brewing method (e.g., "french press")';
                    resultsCount.style.color = '#c79b63';
                    
                    setTimeout(() => {
                        if (searchInput.value === '') {
                            resultsCount.textContent = originalText;
                            resultsCount.style.color = '#6b3e26';
                        }
                    }, 3000);
                }
                searchInput.setAttribute('data-tooltip-shown', 'true');
            }, 500);
        }
    });
    
    // Initialize filter functionality
    initFilters();
});

// Initialize filter functionality
function initFilters() {
    const roastFilter = document.getElementById('roastFilter');
    const priceFilter = document.getElementById('priceFilter');
    const sortOptions = document.getElementById('sortOptions');
    const coffeeCards = document.querySelectorAll('.coffee-card');
    const activeFilterText = document.getElementById('activeFilterText');
    
    if (!roastFilter) return; // If no filter section, exit
    
    // Roast filter function
    function filterByRoast(roastValue) {
        coffeeCards.forEach(card => {
            const cardText = card.textContent.toLowerCase();
            let shouldShow = true;
            
            if (roastValue !== 'all') {
                shouldShow = cardText.includes(roastValue);
            }
            
            // Apply animation
            if (shouldShow) {
                card.classList.remove('hidden');
                setTimeout(() => {
                    card.classList.add('visible');
                }, 50);
            } else {
                card.classList.remove('visible');
                card.classList.add('hidden');
            }
        });
    }
    
    // Price filter function
    function filterByPrice(priceValue) {
        coffeeCards.forEach(card => {
            const priceElement = card.querySelector('.price');
            if (!priceElement) return;
            
            const priceText = priceElement.textContent;
            const price = parseFloat(priceText.replace('$', ''));
            let shouldShow = true;
            
            switch (priceValue) {
                case 'under15':
                    shouldShow = price < 15;
                    break;
                case '15to20':
                    shouldShow = price >= 15 && price <= 20;
                    break;
                case 'over20':
                    shouldShow = price > 20;
                    break;
                default:
                    shouldShow = true;
            }
            
            // Apply animation
            if (shouldShow) {
                card.classList.remove('hidden');
                setTimeout(() => {
                    card.classList.add('visible');
                }, 50);
            } else {
                card.classList.remove('visible');
                card.classList.add('hidden');
            }
        });
    }
    
    // Sort function with animation
    function sortProducts(sortValue) {
        const container = document.querySelector('.coffee-grid');
        const cards = Array.from(coffeeCards);
        
        // Add fade-out animation
        cards.forEach(card => {
            card.style.opacity = '0.5';
            card.style.transition = 'opacity 0.3s ease';
        });
        
        setTimeout(() => {
            cards.sort((a, b) => {
                switch (sortValue) {
                    case 'price-low':
                        const priceA = parseFloat(a.querySelector('.price').textContent.replace('$', ''));
                        const priceB = parseFloat(b.querySelector('.price').textContent.replace('$', ''));
                        return priceA - priceB;
                        
                    case 'price-high':
                        const priceAHigh = parseFloat(a.querySelector('.price').textContent.replace('$', ''));
                        const priceBHigh = parseFloat(b.querySelector('.price').textContent.replace('$', ''));
                        return priceBHigh - priceAHigh;
                        
                    case 'name-asc':
                        const nameA = a.querySelector('h3').textContent.toLowerCase();
                        const nameB = b.querySelector('h3').textContent.toLowerCase();
                        return nameA.localeCompare(nameB);
                        
                    default:
                        return 0;
                }
            });
            
            // Reorder in DOM
            cards.forEach(card => {
                container.appendChild(card);
                card.style.opacity = '1';
            });
        }, 300);
    }
    
    // Update active filter text
    function updateFilterText() {
        if (!activeFilterText) return;
        
        const roastText = roastFilter.options[roastFilter.selectedIndex].text;
        const priceText = priceFilter.options[priceFilter.selectedIndex].text;
        const sortText = sortOptions.options[sortOptions.selectedIndex].text;
        
        activeFilterText.textContent = `Filter: ${roastText} | Price: ${priceText} | Sorted by: ${sortText}`;
    }
    
    // Combined filter function
    function applyAllFilters() {
        const roastValue = roastFilter.value;
        const priceValue = priceFilter.value;
        
        coffeeCards.forEach(card => {
            const cardText = card.textContent.toLowerCase();
            const priceElement = card.querySelector('.price');
            let shouldShow = true;
            
            // Apply roast filter
            if (roastValue !== 'all') {
                shouldShow = shouldShow && cardText.includes(roastValue);
            }
            
            // Apply price filter
            if (priceValue !== 'all' && priceElement) {
                const priceText = priceElement.textContent;
                const price = parseFloat(priceText.replace('$', ''));
                
                switch (priceValue) {
                    case 'under15':
                        shouldShow = shouldShow && price < 15;
                        break;
                    case '15to20':
                        shouldShow = shouldShow && price >= 15 && price <= 20;
                        break;
                    case 'over20':
                        shouldShow = shouldShow && price > 20;
                        break;
                }
            }
            
            // Apply animation
            if (shouldShow) {
                card.classList.remove('hidden');
                setTimeout(() => {
                    card.classList.add('visible');
                }, 50);
            } else {
                card.classList.remove('visible');
                card.classList.add('hidden');
            }
        });
    }
    
    // Event listeners
    roastFilter.addEventListener('change', function() {
        applyAllFilters();
        updateFilterText();
    });
    
    priceFilter.addEventListener('change', function() {
        applyAllFilters();
        updateFilterText();
    });
    
    sortOptions.addEventListener('change', function() {
        sortProducts(this.value);
        updateFilterText();
    });
    
    // Initialize
    updateFilterText();
}
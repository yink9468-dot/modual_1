/* =====================================================
   slider.js – Professional Auto & Manual Slideshow
   Bean Boutique
   ===================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const slider = document.getElementById('heroSlider');
  if (!slider) return;

  const slides = Array.from(slider.querySelectorAll('.slide'));
  const prevBtn = slider.querySelector('.slider-prev');
  const nextBtn = slider.querySelector('.slider-next');

  let current = 0;
  let autoplayInterval = 5000; // Time in milliseconds (5 seconds)
  let timer = null;

  /**
   * showSlide: Handles the transition logic
   * Removes 'active' from all and adds to the target index
   */
  function showSlide(index) {
    slides.forEach((s, i) => {
      const active = i === index;
      s.classList.toggle('active', active);
      // Update accessibility for screen readers
      s.setAttribute('aria-hidden', String(!active));
    });
    current = index;
  }

  function next() {
    showSlide((current + 1) % slides.length);
  }

  function prev() {
    showSlide((current - 1 + slides.length) % slides.length);
  }

  /**
   * Autoplay Management
   */
  function startAutoplay() {
    stopAutoplay(); // Clear any existing timer first
    timer = setInterval(next, autoplayInterval);
  }

  function stopAutoplay() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }

  // --- Manual Button Controls ---
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      next();
      startAutoplay(); // Reset the 5-second timer on manual click
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      prev();
      startAutoplay(); // Reset the 5-second timer on manual click
    });
  }

  // --- Interaction Enhancements ---
  // Pause the slideshow when the user hovers over the slider
  slider.addEventListener('mouseenter', stopAutoplay);
  // Resume the slideshow when the mouse leaves
  slider.addEventListener('mouseleave', startAutoplay);
  
  // Pause when keyboard users focus on elements inside the slider
  slider.addEventListener('focusin', stopAutoplay);
  slider.addEventListener('focusout', startAutoplay);

  // Keyboard Navigation (Arrow Keys)
  slider.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') {
      next();
      startAutoplay();
    } else if (e.key === 'ArrowLeft') {
      prev();
      startAutoplay();
    }
  });

  // --- Initialization ---
  showSlide(0);      // Set initial state
  startAutoplay();   // Start the auto-timer
});
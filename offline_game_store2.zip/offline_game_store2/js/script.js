var navToggle= document.querySelector('.nav_toggle');
var sidebar = document.querySelector('.sidebar_container');

navToggle.addEventListener('click',() =>{
    sidebar.classList.toggle('show_sidebar');
})